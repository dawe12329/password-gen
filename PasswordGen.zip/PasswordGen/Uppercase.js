export function includeUpperCase() {
  if (includeUpperCase) {
    {
      includeUpperCase = false;
    }
  } else {
    includeUpperCase = true;
  }

  console.log(includeUpperCase);
}
