export function includeNumbers() {
  if (includeNumbers) {
    {
      includeNumbers = false;
    }
  } else {
    includeNumbers = true;
  }

  console.log(includeNumbers);
}
