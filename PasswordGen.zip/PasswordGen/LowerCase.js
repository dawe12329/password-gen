export function includeLowerCase() {
  if (includeLowerCase) {
    {
      includeLowerCase = false;
    }
  } else {
    includeLowerCase = true;
  }

  console.log(includeLowerCase);
};
