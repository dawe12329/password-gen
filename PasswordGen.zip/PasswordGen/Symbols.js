export function includeSymbols() {
  if (!includeSymbols) {
    {
      includeSymbols = true;
    }
  } else {
    includeSymbols = false;
  }

  console.log(includeSymbols);
};
